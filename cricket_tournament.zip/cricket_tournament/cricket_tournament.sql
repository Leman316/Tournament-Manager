-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 05, 2018 at 01:36 PM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cricket_tournament`
--

-- --------------------------------------------------------

--
-- Table structure for table `batting_stats`
--

CREATE TABLE `batting_stats` (
  `batting_id` int(11) NOT NULL,
  `batting_style` varchar(20) DEFAULT NULL,
  `no_of_50s` int(11) DEFAULT NULL,
  `no_of_100s` int(11) DEFAULT NULL,
  `scored_4` int(11) DEFAULT NULL,
  `scored_6` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `batting_stats`
--

INSERT INTO `batting_stats` (`batting_id`, `batting_style`, `no_of_50s`, `no_of_100s`, `scored_4`, `scored_6`) VALUES
(2, 'Right-handed', 0, 0, 0, 0),
(7, 'Left-Handed', 0, 0, 0, 0),
(46, 'Left-Handed', 0, 0, 0, 0),
(124, 'Right-handed', 0, 0, 0, 0),
(128, 'Left-Handed', 0, 0, 0, 0),
(222, 'Right-handed', 0, 0, 0, 0),
(330, 'Right-handed', 0, 0, 0, 0),
(333, 'Left-Handed', 0, 0, 0, 0),
(482, 'Right-handed', 0, 0, 0, 0),
(500, 'Left-Handed', 0, 0, 0, 0),
(666, 'Right-handed', 0, 0, 0, 0),
(671, 'Left-Handed', 0, 0, 0, 0),
(844, 'Right-handed', 0, 0, 0, 0),
(987, 'Right-handed', 0, 0, 0, 0),
(999, 'Right-handed', 0, 0, 0, 0),
(1021, 'Right-handed', 0, 0, 0, 0),
(1214, 'Right-handed', 0, 0, 0, 0),
(1356, 'Right-handed', 0, 0, 0, 0),
(1582, 'Right-handed', 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `bowling_stats`
--

CREATE TABLE `bowling_stats` (
  `bowling_id` int(11) NOT NULL,
  `overs` float(4,1) DEFAULT NULL,
  `wickets` int(11) DEFAULT NULL,
  `bowling_style` varchar(20) DEFAULT NULL,
  `best` varchar(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bowling_stats`
--

INSERT INTO `bowling_stats` (`bowling_id`, `overs`, `wickets`, `bowling_style`, `best`) VALUES
(2, 0.0, 0, 'Medium-spin', NULL),
(7, 0.0, 0, 'Offcutter', NULL),
(46, 0.0, 0, 'Medium-spin', NULL),
(124, 0.0, 0, 'Medium-Fast', NULL),
(128, 0.0, 0, 'Legspin', NULL),
(222, 0.0, 0, 'Legspin', NULL),
(330, 0.0, 0, 'Fast-offcutter', NULL),
(333, 0.0, 0, 'Off-Break', NULL),
(482, 0.0, 0, 'Off-Break', NULL),
(500, 0.0, 0, 'Fast-offcutter', NULL),
(666, 0.0, 0, 'Fast', NULL),
(844, 0.0, 0, 'Medium-Fast', NULL),
(987, 0.0, 0, 'Medium-Fast', NULL),
(999, 0.0, 0, 'Fast', NULL),
(1021, 0.0, 0, 'Offcutter', NULL),
(1214, 0.0, 0, 'Legspin', NULL),
(1356, 0.0, 0, 'Off-Break', NULL),
(1582, 0.0, 0, 'Medium-Fast', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ground`
--

CREATE TABLE `ground` (
  `ground_name` varchar(25) NOT NULL,
  `capacity` int(11) DEFAULT NULL,
  `location` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ground`
--

INSERT INTO `ground` (`ground_name`, `capacity`, `location`) VALUES
('chittagong', 15000, NULL),
('mirpur', 25000, NULL),
('Shahjalal', 30000, NULL),
('tejgaon', 40000, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--

CREATE TABLE `manager` (
  `manager_name` varchar(25) NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `nationality` char(20) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `experience` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `manager`
--

INSERT INTO `manager` (`manager_name`, `date_of_birth`, `nationality`, `age`, `experience`) VALUES
('abc', '1994-01-18', 'Bangladeshi', NULL, NULL),
('hasan', '1975-11-11', 'Australian', NULL, NULL),
('karim', '1990-05-03', 'Bangladeshi', NULL, NULL),
('xyz', '1945-05-13', 'Indian', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `matches`
--

CREATE TABLE `matches` (
  `match_no` int(11) NOT NULL,
  `Team_1` varchar(25) DEFAULT NULL,
  `Team_2` varchar(25) DEFAULT NULL,
  `team_1_score` varchar(5) DEFAULT NULL,
  `team_2_score` varchar(5) DEFAULT NULL,
  `result` varchar(50) DEFAULT NULL,
  `ground` varchar(20) DEFAULT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `matches`
--

INSERT INTO `matches` (`match_no`, `Team_1`, `Team_2`, `team_1_score`, `team_2_score`, `result`, `ground`, `date`) VALUES
(1, 'Alpha', 'Bdesh', NULL, NULL, NULL, 'chittagong', '2018-01-13'),
(2, 'Dhaka', 'Omega', NULL, NULL, NULL, 'Shahjalal', '2018-01-14'),
(3, 'Alpha', 'Dhaka', NULL, NULL, NULL, 'tejgaon', '2018-01-16'),
(4, 'Bdesh', 'Omega', NULL, NULL, NULL, 'chittagong', '2018-01-18'),
(5, 'Dhaka', 'Bdesh', NULL, NULL, NULL, 'Shahjalal', '2018-01-20'),
(6, 'Alpha', 'Omega', NULL, NULL, NULL, 'mirpur', '2018-01-22'),
(8, 'Alpha', 'Omega', NULL, NULL, NULL, 'chittagong', '2018-02-27');

-- --------------------------------------------------------

--
-- Table structure for table `match_stats`
--

CREATE TABLE `match_stats` (
  `match_no` int(11) NOT NULL,
  `players_id` int(11) NOT NULL,
  `player_name` varchar(25) DEFAULT NULL,
  `player_team` varchar(25) DEFAULT NULL,
  `run_scored` int(11) DEFAULT NULL,
  `balls_faced` int(11) DEFAULT NULL,
  `overs_bowled` float(3,1) DEFAULT NULL,
  `wickets_taken` int(11) DEFAULT NULL,
  `result` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `players`
--

CREATE TABLE `players` (
  `player_id` int(11) NOT NULL,
  `player_name` varchar(25) NOT NULL,
  `team` varchar(25) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `nationality` char(20) NOT NULL,
  `role` varchar(25) DEFAULT NULL,
  `matches_played` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `players`
--

INSERT INTO `players` (`player_id`, `player_name`, `team`, `date_of_birth`, `nationality`, `role`, `matches_played`) VALUES
(2, 'hussain', 'Omega', '1991-01-16', 'Pakistani', 'AllRounder', NULL),
(7, 'James', 'Dhaka', '1982-12-01', 'Australian', 'Bowler', 0),
(46, 'Salman', 'Bdesh', '1990-02-07', 'Srilankan', 'Batsman', 0),
(124, 'Rafsan', 'Alpha', '1994-01-22', 'Bangladeshi', 'AllRounder', 0),
(128, 'Anik', 'Alpha', '1995-01-26', 'Bangladeshi', 'Bowler', 0),
(222, 'Ahsan', 'Alpha', '1989-12-22', 'Indian', 'Batsman', 0),
(330, 'Hossain', 'Bdesh', '1980-05-18', 'Pakistani', 'AllRounder', 0),
(333, 'Gayle', 'Alpha', '1975-11-11', 'West Indian', 'Batsman', 0),
(482, 'John', 'Dhaka', '1982-04-28', 'Irish', 'Allrounder', 0),
(500, 'Kabir', 'Alpha', '1991-05-22', 'Indian', 'Bowler', 0),
(666, 'Rahman', 'India', '1995-09-27', 'Bangladeshi', 'Batsman', 0),
(671, 'Abul', 'India', '1984-02-15', 'Indian', 'Bowler', 0),
(844, 'Taswar', 'Bdesh', '1988-12-13', 'Indian', 'Batsman', 0),
(987, 'Smith', 'Dhaka', '1990-12-31', 'England', 'Batsman', 0),
(999, 'Ifrad', 'Omega', '1999-09-09', 'Indian', 'Bowler', 0),
(1021, 'Sadman', 'Dhaka', '1975-08-23', 'Bangladeshi', 'Bowler', 0),
(1214, 'Junayed', 'Bdesh', '1974-11-22', 'Australian', 'Bowler', 0),
(1356, 'Abu Hasan', 'India', '1978-05-28', 'Indian', 'Batsman', 0),
(1582, 'John', 'Omega', '1972-08-28', 'England', 'Batsman', 0);

-- --------------------------------------------------------

--
-- Table structure for table `points_table`
--

CREATE TABLE `points_table` (
  `team_name` varchar(25) NOT NULL,
  `played` int(11) DEFAULT NULL,
  `win` int(11) DEFAULT NULL,
  `loss` int(11) DEFAULT NULL,
  `No_Res` int(11) DEFAULT NULL,
  `Points` int(11) DEFAULT NULL,
  `NRR` float(3,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `points_table`
--

INSERT INTO `points_table` (`team_name`, `played`, `win`, `loss`, `No_Res`, `Points`, `NRR`) VALUES
('Alpha', 0, 0, 0, 0, 0, 0.00),
('Bdesh', 0, 0, 0, 0, 0, 0.00),
('Dhaka', 0, 0, 0, 0, 0, 0.00),
('Omega', 0, 0, 0, 0, 0, 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `team_name` varchar(25) NOT NULL,
  `captain` varchar(25) NOT NULL,
  `manager` varchar(25) DEFAULT NULL,
  `homeground` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`team_name`, `captain`, `manager`, `homeground`) VALUES
('Alpha', 'Mashrafe', 'abc', 'mirpur'),
('Bdesh', 'Rafsan', 'xyz', 'Shahjalal'),
('Dhaka', 'rahim', 'karim', 'tejgaon'),
('India', 'Pathan', 'Sachin', 'Kolkata'),
('Omega', 'rahman', 'hasan', 'chittagong');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `batting_stats`
--
ALTER TABLE `batting_stats`
  ADD PRIMARY KEY (`batting_id`);

--
-- Indexes for table `bowling_stats`
--
ALTER TABLE `bowling_stats`
  ADD PRIMARY KEY (`bowling_id`);

--
-- Indexes for table `ground`
--
ALTER TABLE `ground`
  ADD PRIMARY KEY (`ground_name`);

--
-- Indexes for table `manager`
--
ALTER TABLE `manager`
  ADD PRIMARY KEY (`manager_name`);

--
-- Indexes for table `matches`
--
ALTER TABLE `matches`
  ADD PRIMARY KEY (`match_no`),
  ADD KEY `Team_1` (`Team_1`),
  ADD KEY `Team_2` (`Team_2`),
  ADD KEY `ground` (`ground`);

--
-- Indexes for table `match_stats`
--
ALTER TABLE `match_stats`
  ADD PRIMARY KEY (`match_no`,`players_id`);

--
-- Indexes for table `players`
--
ALTER TABLE `players`
  ADD PRIMARY KEY (`player_id`),
  ADD KEY `team` (`team`);

--
-- Indexes for table `points_table`
--
ALTER TABLE `points_table`
  ADD PRIMARY KEY (`team_name`),
  ADD KEY `team_name_2` (`team_name`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`team_name`),
  ADD UNIQUE KEY `homeground` (`homeground`),
  ADD UNIQUE KEY `manager` (`manager`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `batting_stats`
--
ALTER TABLE `batting_stats`
  ADD CONSTRAINT `batting_stats_ibfk_1` FOREIGN KEY (`batting_id`) REFERENCES `players` (`player_id`);

--
-- Constraints for table `bowling_stats`
--
ALTER TABLE `bowling_stats`
  ADD CONSTRAINT `bowling_stats_ibfk_1` FOREIGN KEY (`bowling_id`) REFERENCES `players` (`player_id`);

--
-- Constraints for table `ground`
--
ALTER TABLE `ground`
  ADD CONSTRAINT `ground_ibfk_1` FOREIGN KEY (`ground_name`) REFERENCES `teams` (`homeground`);

--
-- Constraints for table `manager`
--
ALTER TABLE `manager`
  ADD CONSTRAINT `manager_ibfk_1` FOREIGN KEY (`manager_name`) REFERENCES `teams` (`manager`);

--
-- Constraints for table `matches`
--
ALTER TABLE `matches`
  ADD CONSTRAINT `matches_ibfk_1` FOREIGN KEY (`Team_1`) REFERENCES `teams` (`team_name`),
  ADD CONSTRAINT `matches_ibfk_2` FOREIGN KEY (`Team_2`) REFERENCES `teams` (`team_name`),
  ADD CONSTRAINT `matches_ibfk_3` FOREIGN KEY (`ground`) REFERENCES `ground` (`ground_name`);

--
-- Constraints for table `match_stats`
--
ALTER TABLE `match_stats`
  ADD CONSTRAINT `match_stats_ibfk_1` FOREIGN KEY (`match_no`) REFERENCES `matches` (`match_no`);

--
-- Constraints for table `players`
--
ALTER TABLE `players`
  ADD CONSTRAINT `players_ibfk_1` FOREIGN KEY (`team`) REFERENCES `teams` (`team_name`);

--
-- Constraints for table `points_table`
--
ALTER TABLE `points_table`
  ADD CONSTRAINT `points_table_ibfk_1` FOREIGN KEY (`team_name`) REFERENCES `teams` (`team_name`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
