/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cricket_tournament;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JTextField;

/**
 *
 * @author Dell
 */
public class DBhandler {
    
     Connection connect = null;
    
    public void connectDatabase(){
        try{
         //   Class.forName("com.mysql.jdbc.Driver");
            connect = DriverManager.getConnection("jdbc:mysql://localhost/cricket_tournament","root","");
            System.out.println("Successfully Connected to Mysql");

        }catch(Exception e){
            System.out.println("Not Connected..");
            e.printStackTrace();
        }
    }
    

    
    

    ResultSet pts() {
      ResultSet resultSet = null;
        try{
            String query = "SELECT * FROM points_table";
            //String query = "SELECT * FROM info WHERE name LIKE 't%'";
            Statement statement ;
            statement = connect.createStatement();
            resultSet = statement.executeQuery(query);
            
//            String query = "SELECT * FROM student WHERE student_name =? and id_student =?";
//            PreparedStatement pStatement = connect.prepareStatement(query);
//            pStatement.setString(1, "ABC");
//            pStatement.setString(2, "1");
//            resultSet = pStatement.executeQuery();
            
            System.out.println("Successfully Done Query..");
           
        }catch(Exception e){
            System.out.println("Error in Query..");
            e.printStackTrace();
        }           
        return resultSet;
    }

    ResultSet teams() {
        ResultSet resultSet = null;
        try{
          String query = "select t.team_name ,t.captain,t.manager,t.homeground,g.capacity from teams t join ground g on t.homeground=g.ground_name";
            //String query = "SELECT * FROM info WHERE name LIKE 't%'";
            Statement statement ;
            statement = connect.createStatement();
            resultSet = statement.executeQuery(query);
            
//            String query = "SELECT * FROM student WHERE student_name =? and id_student =?";
//            PreparedStatement pStatement = connect.prepareStatement(query);
//            pStatement.setString(1, "ABC");
//            pStatement.setString(2, "1");
//            resultSet = pStatement.executeQuery();
            
            System.out.println("Successfully Done Query..");
           
        }catch(Exception e){
            System.out.println("Error in Query..");
            e.printStackTrace();
        }           
        return resultSet;
      
    }

    ResultSet gnd() {
        ResultSet resultSet = null;
        try{
          String query = "select g.ground_name,g.capacity,g.location,t.team_name from ground g join teams t on g.ground_name=t.homeground";
            //String query = "SELECT * FROM info WHERE name LIKE 't%'";
            Statement statement ;
            statement = connect.createStatement();
            resultSet = statement.executeQuery(query);
            

           // System.out.println("Successfully Done Query..");
           
        }catch(Exception e){
            System.out.println("Error in Query..");
            e.printStackTrace();
        }           
        return resultSet;
    }

    ResultSet sch() {
        
        
    ResultSet resultSet = null;
        try{
          String query = "SELECT * FROM matches";
            //String query = "SELECT * FROM info WHERE name LIKE 't%'";
            Statement statement ;
            statement = connect.createStatement();
            resultSet = statement.executeQuery(query);
            

           // System.out.println("Successfully Done Query..");
           
        }catch(Exception e){
            System.out.println("Error in Query..");
            e.printStackTrace();
        }           
        return resultSet;
        
    
    
}

    void insertTeam(String name, String capt, String manager, String home) {
        try{
            String query = "INSERT INTO teams (team_name, captain,manager,homeground) values(?,?,?,?)";
            PreparedStatement pStatement = connect.prepareStatement(query);
            pStatement.setString(1, name);
            pStatement.setString(2, capt);
            pStatement.setString(3, manager);
            pStatement.setString(4, home);
           
            pStatement.executeUpdate();
            
            System.out.println("Successfully Inserted..");
            
            
        }catch(Exception e){
            System.out.println("Error in inserting");
            e.printStackTrace();
        }
    }

    void insertPlayer(String id, String name, String team, String dob, String nation, String role) {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
         try{
            String query = "INSERT INTO players (player_id ,player_name, team,date_of_birth,nationality,role) values(?,?,?,?,?,?)";
            PreparedStatement pStatement = connect.prepareStatement(query);
            pStatement.setString(1, id);
            pStatement.setString(2, name);
            pStatement.setString(3, team);
            pStatement.setString(4, dob);
             pStatement.setString(5, nation);
              pStatement.setString(6, role);
           
            pStatement.executeUpdate();
            
            System.out.println("Successfully Inserted..");
            
            
        }catch(Exception e){
            System.out.println("Error in inserting");
            e.printStackTrace();
        }
    }

    void insertMatch(String n,String t1, String t2, String venue, String date) {
      //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
      
       try{
            String query = "INSERT INTO matches (match_no, Team_1, Team_2, ground, date) values(?,?,?,?,?)";
            PreparedStatement pStatement = connect.prepareStatement(query);
           pStatement.setString(1,n);
            pStatement.setString(2, t1);
            pStatement.setString(3, t2);
            pStatement.setString(4, venue);
            pStatement.setString(5, date);
           
            pStatement.executeUpdate();
            
            System.out.println("Successfully Inserted..");
            
            
        }catch(Exception e){
            System.out.println("Error in inserting");
            e.printStackTrace();
        }
    }

    ResultSet adp(String a) {
     //   throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
       ResultSet resultSet = null;
        try{
            String s=a;
            String query = "SELECT * FROM players ORDER BY "+s;
            //String query = "SELECT * FROM info WHERE name LIKE 't%'";
            Statement statement ;
            statement = connect.createStatement();
            resultSet = statement.executeQuery(query);
            
//            String query = "SELECT * FROM student WHERE student_name =? and id_student =?";
//            PreparedStatement pStatement = connect.prepareStatement(query);
//            pStatement.setString(1, "ABC");
//            pStatement.setString(2, "1");
//            resultSet = pStatement.executeQuery();
            
            System.out.println("Successfully Done Query.."+s);
           
        }catch(Exception e){
            System.out.println("Error in Query.."+ a);
            e.printStackTrace();
        }           
        return resultSet;
    }

    ResultSet advanced(String name) {
      //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        ResultSet resultSet = null;
        try{
            
         
            String query = "select p.player_name,p.team,p.date_of_birth,p.nationality,p.role,bat.batting_style,bowl.bowling_style \n" +
"from (players p join batting_stats bat on p.player_id=bat.batting_id) join bowling_stats bowl  on bowl.bowling_id=p.player_id\n" +
"where p.player_name like '" + name+"%'" ;
            //String query = "SELECT * FROM info WHERE name LIKE 't%'";
            System.out.println(query);
            Statement statement ;
            statement = connect.createStatement();
            resultSet = statement.executeQuery(query);
           
            
            System.out.println("Successfully Done Query.."+name);
           
        }catch(Exception e){
            System.out.println("Error in Query.."+name);
            e.printStackTrace();
        }           
        return resultSet;
    }

    ResultSet advancedt(String a) {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
          ResultSet resultSet = null;
        try{
            
         
            String query = "select p.player_name,p.team,p.date_of_birth,p.nationality,p.role,bat.batting_style,bowl.bowling_style \n" +
"from (players p join batting_stats bat on p.player_id=bat.batting_id) join bowling_stats bowl  on bowl.bowling_id=p.player_id\n" +
"where p.team like '" + a +"%'" ;
            //String query = "SELECT * FROM info WHERE name LIKE 't%'";
            System.out.println(query);
            Statement statement ;
            statement = connect.createStatement();
            resultSet = statement.executeQuery(query);
           
            
            System.out.println("Successfully Done Query.."+a);
           
        }catch(Exception e){
            System.out.println("Error in Query.."+a);
            e.printStackTrace();
        }           
        return resultSet;
    }

    ResultSet advanced(String a, String b) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
         ResultSet resultSet = null;
        try{
            
         
            String query = "select p.player_name,p.team,p.date_of_birth,p.nationality,p.role,bat.batting_style,bowl.bowling_style \n" +
"from (players p join batting_stats bat on p.player_id=bat.batting_id) join bowling_stats bowl  on bowl.bowling_id=p.player_id\n" +
"where p.player_name like '" + a +"%'" +"&& p.team like '"+ b +"%' " ;
            //String query = "SELECT * FROM info WHERE name LIKE 't%'";
            System.out.println(query);
            Statement statement ;
            statement = connect.createStatement();
            resultSet = statement.executeQuery(query);
           
            
            System.out.println("Successfully Done Query..");
           
        }catch(Exception e){
            System.out.println("Error in Query..");
            e.printStackTrace();
        }           
        return resultSet;
    }

   
}
